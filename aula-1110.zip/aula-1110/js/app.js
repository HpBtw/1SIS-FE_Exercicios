// recuperar o tbody da pagina
const tbody = document.querySelector('#historicoContas');
console.log(tbody);

//recuperar o form - atribuir um listener submit (evento que envia o form) 
// o envio será cancelado - criar uma função para inserir dados na tabela 
document.querySelector('form').addEventListener('submit', function(e) { // coloca-se (e) por costume, pode ser qualquer coisa
    // cancelar o submit
    e.preventDefault();

    const campos = [ // cria o array campos e armazena as informações ali dentro
        document.querySelector('#usuario'),
        document.querySelector('#email'),
        document.querySelector('#dataCadastro'),
        document.querySelector('#tipoConta')
    ];
    console.log(campos);

    // criar uma tr
    const tr = document.createElement('tr');

    // percorrer o array campos
    campos.forEach(campo => {

        // criar uma td (não é possivel escrever em tr's, só em td's)
        const td = document.createElement('td');
        
        // passar o valor do formulário para a td
        td.textContent = campo.value;

        // colocar a td dentro da tr
        tr.appendChild(td) // função que traz o tr pra dentro do for, concebendo um valor
    });

    // colocar a tr dentro do tbody
    tbody.appendChild(tr);

    // limpar o formulário
    this.reset();
});