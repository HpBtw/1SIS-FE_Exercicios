const alunos = [
    {
        matricula: '123456', 
        nome: 'fulano',
        sala: '1sis',
        curso: 'SI'
    },

    {
        matricula: '963852',
        nome: 'ciclano',
        sala: '1sis',
        curso: 'SI'
    },
    {
        matricula: '594734',
        nome: 'beltrano',
        sala: '1sis',
        curso: 'SI'
    }
];

console.log(alunos); // poderia ser aluno[indice] ou aluno[indice].curso por exemplo.
console.table(alunos); 