public class exemplo01 {
	
	public static void main(String[] args) {
		char caractere = 'a'; // a, b, A, B etc.
		int valorUnicode = (int) caractere; // Conversão explícita de char para int
		System.out.println("O valor Unicode do caractere '" + caractere + "' é: " + valorUnicode);
		
		int valor = 40;
		char caractereConv = (char) valor; // Conversão explícita de int para char
		System.out.println("O caractere correspondente ao valor " + valor + " é: " + caractereConv);
	}
}