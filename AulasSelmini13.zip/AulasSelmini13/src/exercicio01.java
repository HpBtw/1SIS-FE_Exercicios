import java.util.Scanner;

public class exercicio01 {

	public static void main(String[] args) {
		Scanner kb = new Scanner(System.in);

		System.out.print("Insira a quantia de palavras: ");
		int quantia = kb.nextInt();

		String[] lista = new String[quantia];
		
		lerPalavra(lista);
		localizarPar(lista);
	}
	
	public static void lerPalavra(String[] lista) {
		Scanner kb = new Scanner(System.in);
		
		for (int i = 0; i < lista.length; i++) {
			System.out.print("Palavra:");
			lista[i] = kb.next();
		}
	}
	
	public static void localizarPar(String[] lista) {
		String palavraInvertida;
		
		for (String palavra : lista) {
			palavraInvertida = inverter(palavra);
		}
	}
	
	public static String inverter(String palavra) {
		char[] letra = new char[palavra.length()];
		
		for (int i = palavra.length()-1; i >= 0; i--) {
			letra[palavra.length() - 1 - i] = palavra.charAt(i);
		}
		String aux = new String(letra);
		System.out.println(aux);
	
	}

}
