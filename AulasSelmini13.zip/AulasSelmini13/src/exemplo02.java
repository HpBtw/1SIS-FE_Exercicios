
public class exemplo02 {

	public static void main(String[] args) {
		String s = "Exemplo";
		int tamanho = s.length(); // retorna 7
		System.out.println(tamanho);
		
		char c = s.charAt(0);
		System.out.println(c);
		
		//contains(): Verifica se uma string contém outra string.
		boolean contem = s.contains("xem"); // retorna true
		System.out.println(contem);
	}

}
