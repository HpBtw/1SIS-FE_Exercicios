// rnging - sorteia um numero entre 0 e 1 (casas decimais)
let firstNumber = Math.random();
console.log(firstNumber);

// gerando uma parte inteira para o número
firstNumber*=100;
console.log(firstNumber);

// retornando apenas a parte inteira do numero
// firstNumber = parseInt(firstNumber); 

// retornando o próximo número inteiro
// firstNumber = Math.ceil(firstNumber);

// retornando o mesmo inteiro
// firstNumber = Math.floor(firstNumber);

// retorna o proximo inteiro caso a decimal seja > 5
// retorna o mesmo inteiro caso a decimal seja < 5 
firstNumber = Math.round(firstNumber);
console.log(firstNumber);

// criação de variável já adaptada à inteiro
const firstNumberConst = Math.round(Math.random()*100);
console.log(firstNumberConst);

// disponibiliza o conteudo do texto (textContent) para o query pegar e enviar para o html via id
document.querySelector('#firstNumber').textContent = firstNumber;
document.querySelector('#firstNumberConst').textContent = firstNumberConst;

let result = firstNumber + firstNumberConst;
document.querySelector('#sum').textContent = result;

result = firstNumber - firstNumberConst;
document.querySelector('#subtraction').textContent = result;

result = firstNumber * firstNumberConst;
document.querySelector('#multiplication').textContent = result;

// toFixed formata o número de casas decimais do numero toFixed(nCasas)
result = firstNumber / firstNumberConst;
document.querySelector('#division').textContent = result.toFixed(2);

// calculador de potencia x ** y = x^y
result = firstNumber ** firstNumberConst;
document.querySelector('#potency').textContent = result.toFixed(2);

// =========================================================================================

// criação de array -- const v = [1, 2, 3, 'string', true (bool)]
// const v = [];
// console.table(); // cria uma tabela com indice x valor do array

const v = [];
// pegar o botão, adicionar um listener (função que percebe eventos [como clique, hover, alt tabbing, etc])
// e criar uma função quando o botão for clicado

document.querySelector('#btnArray').addEventListener('click', function() { // criação de função
    // alert('botao clicado'); // cria um alerta no topo da página quando o botão é pressionado
    for(let i = 0; i <= 9; i++) {
        v[i] = Math.round(Math.random()*100);
    }
    document.querySelector('#array').textContent = v;
});

document.querySelector('#btnMaior').addEventListener('click', () => { // linhazinha que substitui function()
    let maior = Math.max(...v); // (...(spread) espalha o array numa mesa para que seus valores possam ser utilizadas)
    // math.max pega o maior valor do array

    // for(let i = 0; i <= v.length; i++){ // for para pegar o maior valor
    //     if (v[i] > maior) {
    //         maior = v[i];
    //     }
    // }
    document.querySelector('#maiorArray').textContent = maior;
})

document.querySelector('#btnMenor').addEventListener('click', () => { // linhazinha que substitui function()
    let maior = Math.min(...v); // (...(spread) espalha o array numa mesa para que seus valores possam ser utilizadas)
    // math.min pega o maior valor do array

    document.querySelector('#menorArray').textContent = maior;
});

const arrayMultiplicado = [];
document.querySelector('#btnMultiplica').addEventListener('click', () => { 
    arrayMultiplicado.splice(0); // exclui o conteudo do array
    v.forEach(v => {
        arrayMultiplicado.push(v * 2);
    })
    document.querySelector('#arrayMultiplicado').textContent = arrayMultiplicado;
})

const pessoas = ['Eu', 'Tu', 'Ele', 'Nós', 'Vós', 'Eles'];

// inserir no inicio
pessoas.unshift('qq pessoa');

// exclui o primeiro valor do array
pessoas.shift();

// inserir no final do array
pessoas.push('qq pessoa');

// exclui o ultimo valor do array
pessoas.pop();

// inserir e excluir em qualquer posição do array
// exclui // 2,2 pq como o primeiro é excluido, o index perde 1 na contagem
// se só 1 valor for especificado, todos os valores a partir dele serão excluidos (1 -> 1 em diante)
pessoas.splice(2, 2);
console.table(pessoas);

// insere
pessoas.splice(2,0,'Ele', 'Nós');

// juntando
pessoas.splice(3,2,'qq pessoa', 'outra pessoa');

document.querySelector('#arrayPessoas').textContent = pessoas;

