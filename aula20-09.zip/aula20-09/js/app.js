// console - navegador
console.log('Olá');

// variáveis - JS fracamente tipado (não há tipos para a criação de variáveis como int, string)
// tipagem acontece no momento da atribuição
// as 2 variáveis: 'let' (variavel que pode ser alterada) e 'const' (variavel que nao pode ser alterada)
// let e const tem um escopo (onde a variavel é exergada) de bloco e de função
let nomeUsuario = 'Lu';
let emailUsuario = 'luciano@hotmail.com'
let idUsuario = 559975;
let loggedIn = true;
const DATA_NASCIMENTO = '29/06/2004'; // quando cria-se um const, é de boa prática declarar a variável dessa forma (maiúscula com underline)

//também existe a variável var, mas como o escopo dela é global, pouco usa-se tal definição
// NÃO USAR VAR NÃO USAR VAR NÃO USAR VAR NÃO USAR VAR NÃO USAR VAR NÃO USAR VAR NÃO USAR VAR NÃO USAR VAR NÃO USAR VAR NÃO USAR VAR NÃO USAR VAR NÃO USAR VAR NÃO USAR VAR NÃO USAR VAR NÃO USAR VAR NÃO USAR VAR NÃO USAR VAR NÃO USAR VAR NÃO USAR VAR NÃO USAR VAR NÃO USAR VAR NÃO USAR VAR NÃO USAR VAR NÃO USAR VAR NÃO USAR VAR NÃO USAR VAR NÃO USAR VAR NÃO USAR VAR NÃO USAR VAR NÃO USAR VAR 

console.log(nomeUsuario, emailUsuario);
console.log(idUsuario, loggedIn);
console.log(DATA_NASCIMENTO);

// typeof - Exibe o tipo da variável
console.log(nomeUsuario, typeof(nomeUsuario)); // comando pra printar a variável e, em seguida o tipo

loggedIn = true; // é possivel redefinir o valor da variável, mas não redefina seu tipo (let/const)
console.log(loggedIn); // print do novo valor de loggedIn

// lembrete, const é uma variável não alteravel - (DATA_NASCIMENTO = 'novaData') não existe

// NÃO FAZER CONCATENAÇÕES EM JS, USE TEMPLATE

// template string = template literal
// começa e termina com ``
// Utilização de placeholders: ${variável - método - objeto - cálculo}
console.log(`Usuário ${nomeUsuario} Email ${emailUsuario}`);
// Também faz calculos log(`${variavel - 12163}`)

// Usado para pegar alguma coisa do documento HTML
const minhaDiv = document.getElementById('divUsuario');

minhaDiv.innerHTML = `
        <ul>
            <li class="bg-warning p-3">${nomeUsuario}</li>
            <li>${idUsuario}</li>
            <li>${emailUsuario}</li>
            <li>${loggedIn}</li>
        </ul>
`
